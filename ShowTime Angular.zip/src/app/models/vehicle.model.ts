export class Vehicle{
    vehicleid!: string;
    vehicle_type!: string;
    cost!: string;
}