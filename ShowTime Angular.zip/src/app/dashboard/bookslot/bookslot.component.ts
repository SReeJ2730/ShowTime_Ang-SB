import { Component, OnInit, Input, Directive, HostListener } from '@angular/core';
import { BookingsService } from '../../services/bookings.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Vehicle } from '../../models/vehicle.model';
import { VehicleService } from '../../services/vehicle.service';
import { Slots } from '../../models/slots.model';
import { SlotsService } from '../../services/slots.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-bookslot',
  templateUrl: './bookslot.component.html',
  styleUrls: ['./bookslot.component.css']
})
export class BookslotComponent implements OnInit {

    load: boolean = false;
    vehicles$: Vehicle[] = [];
    slots$: Slots[] = [];
    locationid = this.actRoute.snapshot.params['locationid'];
    //bannerimage = this.actRoute.snapshot.params['bannerimage'];
    //locationname = this.actRoute.snapshot.params['location_image'];
    currentDate = new Date();
    date = this.currentDate.getDate() + '-' + this.currentDate.getMonth() + '-' + this.currentDate.getFullYear()
    
  @Input() bookingdetails = {
    'email':'',
    'locationid':'',
    'vehicle_type':'',
    'duration':0,
    'time':'',
    'slotid':'',
    'date': '',
    'vehicle_no':'',
  }
  constructor(
    private bookings:BookingsService, 
    private slotsService: SlotsService, 
    private vehicleService: VehicleService, 
    public actRoute :ActivatedRoute, 
    public router: Router) { }

  ngOnInit(): void {
    this.load = false;
    this.getVehicles();
    this.getSlotById();
  }

  getVehicles(){
    return this.vehicleService.getVehicles()
    .subscribe(data => this.vehicles$ = data)
  }
  getSlotById(){
    return this.slotsService.getSlotById(this.locationid)
    .subscribe(data => this.slots$ = data)
  }

  addBooking(){
    if(this.bookingdetails.vehicle_type == '' || this.bookingdetails.slotid == '' || this.bookingdetails.duration == 0){
      alert('Kindly fill all the data')
      return
    } 
    /*if (!this.checkTime(this.bookingdetails.time)){
      alert("OOPS!! Try booking 2 hours earlier..")
      return
    }*/
    this.load = true;
    this.bookings.addBooking(this.locationid, this.bookingdetails)
    .subscribe((data:{}) => {
      alert('Show Booked');
      this.router.navigate(['/dashboard/bookings'])
    })
  }
  /*checkTime(bookingTime){

  var currentTime = new Date();
  
  var ISTTime = new Date(currentTime.getTime() + (330 + currentTime.getTimezoneOffset())*60000)
  ISTTime.setHours(ISTTime.getHours()+2)
  
  var time = bookingTime.split(':')
  var h = parseInt(time[0])
  var m = parseInt(time[1])
  if (h<ISTTime.getHours() || (h == ISTTime.getHours() && m < ISTTime.getMinutes())){
      return false
  }
    return true;
  }*/
}
