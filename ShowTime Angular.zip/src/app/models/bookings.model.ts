export class Bookings{
[x: string]: any;
    bookingid!: number;
    email!: string;
    vehicle_type!: string;
    vehicle_no!: string;
    date!: string;
    time!: string;
    duration!: number;
    cost!: string;
    locationid!: number;
    slotid!: string;
    paid!: number;
}