export class Users{
    email!: string;
    fullname!: string;
    mobno!: string;
    password!: string;
}