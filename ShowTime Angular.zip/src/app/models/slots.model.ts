export class Slots{
    slotid!: string;
    locationid!: number;
    slotno!: string;
    status!: number;
    duration!: number;
}